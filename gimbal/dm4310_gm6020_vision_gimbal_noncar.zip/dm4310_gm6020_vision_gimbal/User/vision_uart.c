#include "vision_uart.h"
#include "vision_protocol.h"
#include "gimbal_control.h"
#include "usart.h"
#include <string.h>

#define VISION_RX_RING_SIZE 256U
#define VISION_RX_RING_MASK (VISION_RX_RING_SIZE - 1U)

volatile vision_uart_stats_t vision_uart_stats;

static uint8_t rx_ring[VISION_RX_RING_SIZE];
static volatile uint16_t rx_head;
static volatile uint16_t rx_tail;
static uint8_t rx_byte;

static void restart_uart_receive(void)
{
  (void)HAL_UART_Receive_IT(&huart1, &rx_byte, 1U);
}

void vision_uart_start(void)
{
  memset(rx_ring, 0, sizeof(rx_ring));
  memset((void *)&vision_uart_stats, 0, sizeof(vision_uart_stats));
  rx_head = 0U;
  rx_tail = 0U;
  restart_uart_receive();
}

void vision_uart_process(void)
{
  vision_measurement_t measurement;

  while (rx_tail != rx_head)
  {
    uint8_t byte = rx_ring[rx_tail];
    rx_tail = (uint16_t)((rx_tail + 1U) & VISION_RX_RING_MASK);
    if (vision_protocol_feed_byte(byte, &measurement) != 0U)
    {
      gimbal_control_submit_measurement(&measurement, HAL_GetTick());
    }
  }
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
  if (huart->Instance == USART1)
  {
    uint16_t next_head = (uint16_t)((rx_head + 1U) & VISION_RX_RING_MASK);
    if (next_head != rx_tail)
    {
      rx_ring[rx_head] = rx_byte;
      rx_head = next_head;
      vision_uart_stats.received_byte_count++;
    }
    else
    {
      vision_uart_stats.overflow_count++;
    }
    restart_uart_receive();
  }
}

void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart)
{
  if (huart->Instance == USART1)
  {
    vision_uart_stats.uart_error_count++;
    restart_uart_receive();
  }
}
