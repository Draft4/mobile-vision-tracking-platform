#ifndef __MOTION_DEMO_H__
#define __MOTION_DEMO_H__

#include "main.h"

/* ================= User-adjustable test parameters ================= */
#define DM_TEST_RATE_DEG_S              30.0f
#define DM_TEST_AMPLITUDE_DEG           50.0f
#define DM_TEST_DIRECTION                1.0f
#define DM_MIT_KP                       25.0f
#define DM_MIT_KD                        1.0f

#define GM_TEST_RATE_DEG_S              20.0f
#define GM_TEST_AMPLITUDE_DEG           30.0f
#define GM_TEST_DIRECTION                1.0f
#define GM_PWM_CENTER_US               1500.0f
#define GM_PWM_MIN_US                  1080.0f
#define GM_PWM_MAX_US                  1920.0f
#define GM_PWM_US_PER_DEG                2.3333333333f

#define DEMO_START_HOLD_MS             1000U
/* =================================================================== */

typedef enum
{
  DEMO_START_HOLD = 0,
  DEMO_BOTH_RUNNING
} motion_demo_state_t;

typedef struct
{
  motion_demo_state_t state;
  float dm_relative_angle_deg;
  float gm_relative_angle_deg;
  uint16_t gm_pulse_us;
  uint32_t dm_cycle_count;
  uint32_t gm_cycle_count;
} motion_demo_telemetry_t;

extern volatile motion_demo_telemetry_t motion_demo_telemetry;

void motion_demo_init(float dm_zero_position_rad);
void motion_demo_tick_1khz(void);

#endif /* __MOTION_DEMO_H__ */
