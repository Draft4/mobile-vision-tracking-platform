#ifndef __GIMBAL_CONTROL_H__
#define __GIMBAL_CONTROL_H__

#include "main.h"
#include "vision_protocol.h"

/* ================= User-adjustable control parameters ================= */
#define DM_MIT_KP                         25.0f
#define DM_MIT_KD                          1.0f

/* Change either sign if the corresponding motor moves opposite to vision. */
#define PITCH_MOTOR_DIRECTION              1.0f
#define YAW_MOTOR_DIRECTION                1.0f

/* Vision error -> commanded target velocity (deg/s per degree of error). */
#define VISION_PITCH_RATE_KP                2.0f
#define VISION_YAW_RATE_KP                  2.0f
#define PITCH_MAX_TRACK_RATE_DEG_S         30.0f
#define YAW_MAX_TRACK_RATE_DEG_S           40.0f
#define VISION_ERROR_DEADBAND_DEG           0.30f
#define VISION_ERROR_FILTER_ALPHA           0.50f
#define VISION_MAX_ABS_ERROR_DEG           180.0f

/* Position limits are relative to the power-on pitch zero and GM PWM center. */
#define PITCH_MIN_ANGLE_DEG                -45.0f
#define PITCH_MAX_ANGLE_DEG                 45.0f
#define YAW_MIN_ANGLE_DEG                 -150.0f
#define YAW_MAX_ANGLE_DEG                  150.0f

/* Vision validity and target-loss timing for a roughly 10-20 Hz camera. */
#define VISION_MAX_MEASUREMENT_AGE_MS      100U
#define VISION_VALID_HOLD_TIMEOUT_MS       250U
#define VISION_SEARCH_START_TIMEOUT_MS    1000U
#define VISION_COMM_OFFLINE_TIMEOUT_MS    1000U
#define VISION_MIN_CONFIDENCE_PERMILLE       0U

/* GM6020 PWM position mode and target-loss scan settings. */
#define GM_PWM_CENTER_US                  1500.0f
#define GM_PWM_MIN_US                     1080.0f
#define GM_PWM_MAX_US                     1920.0f
#define GM_PWM_US_PER_DEG                    2.3333333333f
#define GM_SEARCH_RATE_DEG_S                10.0f
/* ===================================================================== */

typedef enum
{
  GIMBAL_HOLD = 0,
  GIMBAL_TRACKING,
  GIMBAL_SEARCHING
} gimbal_state_t;

typedef struct
{
  gimbal_state_t state;
  uint8_t vision_online;
  uint8_t measurement_active;
  uint8_t vision_mode;
  uint8_t tracking_state;
  float yaw_error_deg;
  float pitch_error_deg;
  float yaw_target_deg;
  float pitch_target_deg;
  float yaw_rate_command_deg_s;
  float pitch_rate_command_deg_s;
  uint16_t gm_pulse_us;
  uint32_t last_packet_age_ms;
  uint32_t last_valid_age_ms;
  uint32_t accepted_measurement_count;
  uint32_t rejected_measurement_count;
  uint32_t duplicate_measurement_count;
} gimbal_telemetry_t;

extern volatile gimbal_telemetry_t gimbal_telemetry;

void gimbal_control_init(float dm_zero_position_rad);
void gimbal_control_submit_measurement(const vision_measurement_t *measurement,
                                       uint32_t reception_time_ms);
void gimbal_control_tick_1khz(void);

#endif /* __GIMBAL_CONTROL_H__ */
