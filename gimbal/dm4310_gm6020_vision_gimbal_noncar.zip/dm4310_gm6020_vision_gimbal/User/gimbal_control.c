#include "gimbal_control.h"
#include "dm_motor_ctrl.h"
#include "tim.h"
#include <string.h>

#define URAD_TO_DEG                       0.00005729577951308232f
#define DEG_TO_RAD                        0.01745329251994329577f
#define CONTROL_PERIOD_S                  0.001f
#define GM_UPDATE_DIVIDER                20U

volatile gimbal_telemetry_t gimbal_telemetry;

static float dm_zero_rad;
static float filtered_yaw_error_deg;
static float filtered_pitch_error_deg;
static float yaw_target_deg;
static float pitch_target_deg;
static float search_direction;
static uint32_t init_time_ms;
static uint32_t last_packet_ms;
static uint32_t last_valid_ms;
static uint32_t last_frame_id;
static uint32_t last_track_id;
static uint16_t last_packet_sequence;
static uint8_t have_packet;
static uint8_t have_valid_measurement;
static uint8_t have_sequence;
static volatile uint8_t measurement_active;
static uint8_t gm_update_counter;

static float clampf(float value, float minimum, float maximum)
{
  if (value > maximum)
  {
    return maximum;
  }
  if (value < minimum)
  {
    return minimum;
  }
  return value;
}

static float absf(float value)
{
  return (value < 0.0f) ? -value : value;
}

static float apply_deadband(float error_deg)
{
  if (absf(error_deg) <= VISION_ERROR_DEADBAND_DEG)
  {
    return 0.0f;
  }
  return error_deg;
}

static void update_gm_pwm(void)
{
  float pulse = GM_PWM_CENTER_US +
                YAW_MOTOR_DIRECTION * yaw_target_deg * GM_PWM_US_PER_DEG;
  pulse = clampf(pulse, GM_PWM_MIN_US, GM_PWM_MAX_US);
  __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, (uint32_t)(pulse + 0.5f));
  gimbal_telemetry.gm_pulse_us = (uint16_t)(pulse + 0.5f);
}

void gimbal_control_init(float dm_zero_position_rad)
{
  uint32_t now = HAL_GetTick();

  memset((void *)&gimbal_telemetry, 0, sizeof(gimbal_telemetry));
  dm_zero_rad = dm_zero_position_rad;
  filtered_yaw_error_deg = 0.0f;
  filtered_pitch_error_deg = 0.0f;
  yaw_target_deg = 0.0f;
  pitch_target_deg = 0.0f;
  search_direction = 1.0f;
  init_time_ms = now;
  last_packet_ms = now;
  last_valid_ms = now;
  last_frame_id = 0U;
  last_track_id = 0U;
  last_packet_sequence = 0U;
  have_packet = 0U;
  have_valid_measurement = 0U;
  have_sequence = 0U;
  measurement_active = 0U;
  gm_update_counter = 0U;

  gimbal_telemetry.state = GIMBAL_HOLD;
  motor[Motor1].ctrl.mode = mit_mode;
  motor[Motor1].ctrl.pos_set = dm_zero_rad;
  motor[Motor1].ctrl.vel_set = 0.0f;
  motor[Motor1].ctrl.kp_set = DM_MIT_KP;
  motor[Motor1].ctrl.kd_set = DM_MIT_KD;
  motor[Motor1].ctrl.tor_set = 0.0f;
  update_gm_pwm();
}

void gimbal_control_submit_measurement(const vision_measurement_t *measurement,
                                       uint32_t reception_time_ms)
{
  float yaw_error_deg;
  float pitch_error_deg;
  uint8_t semantic_valid;
  uint8_t duplicate;
  uint32_t primask;

  yaw_error_deg = (float)measurement->yaw_error_urad * URAD_TO_DEG;
  pitch_error_deg = (float)measurement->elevation_error_urad * URAD_TO_DEG;

  semantic_valid = (((measurement->flags & 0x01U) != 0U) &&
                    (measurement->tracking_state == VISION_TRACKING) &&
                    ((measurement->mode == VISION_MODE_TARGET) ||
                     (measurement->mode == VISION_MODE_DRONE)) &&
                    (measurement->measurement_age_ms <= VISION_MAX_MEASUREMENT_AGE_MS) &&
                    (measurement->confidence_permille >= VISION_MIN_CONFIDENCE_PERMILLE) &&
                    (absf(yaw_error_deg) <= VISION_MAX_ABS_ERROR_DEG) &&
                    (absf(pitch_error_deg) <= VISION_MAX_ABS_ERROR_DEG));

  duplicate = ((have_sequence != 0U) &&
               ((measurement->packet_sequence == last_packet_sequence) ||
                ((measurement->frame_id == last_frame_id) &&
                 (measurement->track_id == last_track_id))));

  primask = __get_PRIMASK();
  __disable_irq();

  have_packet = 1U;
  last_packet_ms = reception_time_ms;
  gimbal_telemetry.vision_mode = measurement->mode;
  gimbal_telemetry.tracking_state = measurement->tracking_state;

  if (duplicate != 0U)
  {
    gimbal_telemetry.duplicate_measurement_count++;
  }
  else
  {
    last_packet_sequence = measurement->packet_sequence;
    last_frame_id = measurement->frame_id;
    last_track_id = measurement->track_id;
    have_sequence = 1U;

    if (semantic_valid != 0U)
    {
      if ((have_valid_measurement == 0U) ||
          ((reception_time_ms - last_valid_ms) > VISION_VALID_HOLD_TIMEOUT_MS))
      {
        filtered_yaw_error_deg = yaw_error_deg;
        filtered_pitch_error_deg = pitch_error_deg;
      }
      else
      {
        filtered_yaw_error_deg += VISION_ERROR_FILTER_ALPHA *
                                  (yaw_error_deg - filtered_yaw_error_deg);
        filtered_pitch_error_deg += VISION_ERROR_FILTER_ALPHA *
                                    (pitch_error_deg - filtered_pitch_error_deg);
      }
      last_valid_ms = reception_time_ms;
      have_valid_measurement = 1U;
      measurement_active = 1U;
      gimbal_telemetry.accepted_measurement_count++;
    }
    else
    {
      measurement_active = 0U;
      gimbal_telemetry.rejected_measurement_count++;
    }
  }

  if (primask == 0U)
  {
    __enable_irq();
  }
}

void gimbal_control_tick_1khz(void)
{
  uint32_t now = HAL_GetTick();
  uint32_t packet_age = have_packet ? (now - last_packet_ms) : (now - init_time_ms);
  uint32_t valid_age = have_valid_measurement ? (now - last_valid_ms) : (now - init_time_ms);
  float yaw_rate = 0.0f;
  float pitch_rate = 0.0f;

  if ((measurement_active != 0U) &&
      (valid_age <= VISION_VALID_HOLD_TIMEOUT_MS))
  {
    gimbal_telemetry.state = GIMBAL_TRACKING;
    yaw_rate = clampf(VISION_YAW_RATE_KP * apply_deadband(filtered_yaw_error_deg),
                      -YAW_MAX_TRACK_RATE_DEG_S,
                      YAW_MAX_TRACK_RATE_DEG_S);
    pitch_rate = clampf(VISION_PITCH_RATE_KP * apply_deadband(filtered_pitch_error_deg),
                        -PITCH_MAX_TRACK_RATE_DEG_S,
                        PITCH_MAX_TRACK_RATE_DEG_S);
    yaw_target_deg += yaw_rate * CONTROL_PERIOD_S;
    pitch_target_deg += pitch_rate * CONTROL_PERIOD_S;
  }
  else if (valid_age >= VISION_SEARCH_START_TIMEOUT_MS)
  {
    gimbal_telemetry.state = GIMBAL_SEARCHING;
    yaw_rate = search_direction * GM_SEARCH_RATE_DEG_S;
    yaw_target_deg += yaw_rate * CONTROL_PERIOD_S;

    if (yaw_target_deg >= YAW_MAX_ANGLE_DEG)
    {
      yaw_target_deg = YAW_MAX_ANGLE_DEG;
      search_direction = -1.0f;
    }
    else if (yaw_target_deg <= YAW_MIN_ANGLE_DEG)
    {
      yaw_target_deg = YAW_MIN_ANGLE_DEG;
      search_direction = 1.0f;
    }
  }
  else
  {
    gimbal_telemetry.state = GIMBAL_HOLD;
  }

  if (valid_age > VISION_VALID_HOLD_TIMEOUT_MS)
  {
    measurement_active = 0U;
  }

  yaw_target_deg = clampf(yaw_target_deg, YAW_MIN_ANGLE_DEG, YAW_MAX_ANGLE_DEG);
  pitch_target_deg = clampf(pitch_target_deg,
                            PITCH_MIN_ANGLE_DEG,
                            PITCH_MAX_ANGLE_DEG);

  motor[Motor1].ctrl.pos_set = dm_zero_rad +
                               PITCH_MOTOR_DIRECTION * pitch_target_deg * DEG_TO_RAD;
  motor[Motor1].ctrl.vel_set = 0.0f;
  motor[Motor1].ctrl.kp_set = DM_MIT_KP;
  motor[Motor1].ctrl.kd_set = DM_MIT_KD;
  motor[Motor1].ctrl.tor_set = 0.0f;

  gm_update_counter++;
  if (gm_update_counter >= GM_UPDATE_DIVIDER)
  {
    gm_update_counter = 0U;
    update_gm_pwm();
  }

  gimbal_telemetry.vision_online =
      (uint8_t)((have_packet != 0U) &&
                (packet_age <= VISION_COMM_OFFLINE_TIMEOUT_MS));
  gimbal_telemetry.measurement_active = measurement_active;
  gimbal_telemetry.yaw_error_deg = filtered_yaw_error_deg;
  gimbal_telemetry.pitch_error_deg = filtered_pitch_error_deg;
  gimbal_telemetry.yaw_target_deg = yaw_target_deg;
  gimbal_telemetry.pitch_target_deg = pitch_target_deg;
  gimbal_telemetry.yaw_rate_command_deg_s = yaw_rate;
  gimbal_telemetry.pitch_rate_command_deg_s = pitch_rate;
  gimbal_telemetry.last_packet_age_ms = packet_age;
  gimbal_telemetry.last_valid_age_ms = valid_age;
}
