#ifndef __VISION_UART_H__
#define __VISION_UART_H__

#include "main.h"

typedef struct
{
  uint32_t received_byte_count;
  uint32_t overflow_count;
  uint32_t uart_error_count;
} vision_uart_stats_t;

extern volatile vision_uart_stats_t vision_uart_stats;

void vision_uart_start(void);
void vision_uart_process(void);

#endif /* __VISION_UART_H__ */
