#include "vision_protocol.h"
#include <string.h>

volatile vision_protocol_stats_t vision_protocol_stats;

static uint8_t frame_buffer[VISION_FRAME_LENGTH];
static uint8_t frame_index;

static uint16_t read_u16_le(const uint8_t *data)
{
  return (uint16_t)data[0] | ((uint16_t)data[1] << 8);
}

static uint32_t read_u32_le(const uint8_t *data)
{
  return (uint32_t)data[0] |
         ((uint32_t)data[1] << 8) |
         ((uint32_t)data[2] << 16) |
         ((uint32_t)data[3] << 24);
}

uint16_t vision_crc16_ccitt_false(const uint8_t *data, uint16_t length)
{
  uint16_t crc = 0xFFFFU;
  uint16_t i;
  uint8_t bit;

  for (i = 0U; i < length; i++)
  {
    crc ^= (uint16_t)data[i] << 8;
    for (bit = 0U; bit < 8U; bit++)
    {
      if ((crc & 0x8000U) != 0U)
      {
        crc = (uint16_t)((crc << 1) ^ 0x1021U);
      }
      else
      {
        crc <<= 1;
      }
    }
  }
  return crc;
}

static void resync_after_bad_frame(void)
{
  uint8_t i;

  for (i = 1U; i < (VISION_FRAME_LENGTH - 1U); i++)
  {
    if ((frame_buffer[i] == 0xA5U) && (frame_buffer[i + 1U] == 0x5AU))
    {
      frame_index = (uint8_t)(VISION_FRAME_LENGTH - i);
      memmove(frame_buffer, &frame_buffer[i], frame_index);
      return;
    }
  }

  if (frame_buffer[VISION_FRAME_LENGTH - 1U] == 0xA5U)
  {
    frame_buffer[0] = 0xA5U;
    frame_index = 1U;
  }
  else
  {
    frame_index = 0U;
  }
}

void vision_protocol_init(void)
{
  memset(frame_buffer, 0, sizeof(frame_buffer));
  memset((void *)&vision_protocol_stats, 0, sizeof(vision_protocol_stats));
  frame_index = 0U;
}

uint8_t vision_protocol_feed_byte(uint8_t byte, vision_measurement_t *measurement)
{
  uint16_t received_crc;
  uint16_t calculated_crc;

  if (frame_index == 0U)
  {
    if (byte == 0xA5U)
    {
      frame_buffer[0] = byte;
      frame_index = 1U;
    }
    return 0U;
  }

  if (frame_index == 1U)
  {
    if (byte == 0x5AU)
    {
      frame_buffer[1] = byte;
      frame_index = 2U;
    }
    else if (byte != 0xA5U)
    {
      frame_index = 0U;
    }
    return 0U;
  }

  frame_buffer[frame_index++] = byte;
  if (frame_index < VISION_FRAME_LENGTH)
  {
    return 0U;
  }

  if ((frame_buffer[2] != VISION_PROTOCOL_VERSION) ||
      (frame_buffer[3] != VISION_MESSAGE_MEASUREMENT) ||
      (frame_buffer[4] != VISION_FRAME_LENGTH))
  {
    vision_protocol_stats.format_error_count++;
    resync_after_bad_frame();
    return 0U;
  }

  received_crc = read_u16_le(&frame_buffer[30]);
  calculated_crc = vision_crc16_ccitt_false(frame_buffer, 30U);
  if (received_crc != calculated_crc)
  {
    vision_protocol_stats.crc_error_count++;
    resync_after_bad_frame();
    return 0U;
  }

  measurement->flags = frame_buffer[5];
  measurement->packet_sequence = read_u16_le(&frame_buffer[6]);
  measurement->frame_id = read_u32_le(&frame_buffer[8]);
  measurement->track_id = read_u32_le(&frame_buffer[12]);
  measurement->yaw_error_urad = (int32_t)read_u32_le(&frame_buffer[16]);
  measurement->elevation_error_urad = (int32_t)read_u32_le(&frame_buffer[20]);
  measurement->measurement_age_ms = read_u16_le(&frame_buffer[24]);
  measurement->confidence_permille = read_u16_le(&frame_buffer[26]);
  measurement->tracking_state = frame_buffer[28];
  measurement->mode = frame_buffer[29];

  vision_protocol_stats.valid_frame_count++;
  frame_index = 0U;
  return 1U;
}
