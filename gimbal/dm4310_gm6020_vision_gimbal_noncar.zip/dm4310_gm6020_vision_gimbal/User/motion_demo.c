#include "motion_demo.h"
#include "dm_motor_ctrl.h"
#include "tim.h"
#include <string.h>

#define DEG_TO_RAD                       0.01745329251994329577f
#define CONTROL_PERIOD_S                 0.001f
#define GM_UPDATE_DIVIDER                20U

volatile motion_demo_telemetry_t motion_demo_telemetry;

static float dm_zero_rad;
static float dm_relative_deg;
static float gm_relative_deg;
static float dm_motion_direction;
static float gm_motion_direction;
static uint16_t state_tick;
static uint8_t gm_update_counter;

static float clampf(float value, float minimum, float maximum)
{
  if (value > maximum)
  {
    return maximum;
  }
  if (value < minimum)
  {
    return minimum;
  }
  return value;
}

static void set_state(motion_demo_state_t next_state)
{
  motion_demo_telemetry.state = next_state;
  state_tick = 0U;
}

static void update_gm_pwm(void)
{
  float pulse = GM_PWM_CENTER_US +
                GM_TEST_DIRECTION * gm_relative_deg * GM_PWM_US_PER_DEG;
  pulse = clampf(pulse, GM_PWM_MIN_US, GM_PWM_MAX_US);
  __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, (uint32_t)(pulse + 0.5f));
  motion_demo_telemetry.gm_pulse_us = (uint16_t)(pulse + 0.5f);
}

void motion_demo_init(float dm_zero_position_rad)
{
  memset((void *)&motion_demo_telemetry, 0, sizeof(motion_demo_telemetry));
  dm_zero_rad = dm_zero_position_rad;
  dm_relative_deg = 0.0f;
  gm_relative_deg = 0.0f;
  dm_motion_direction = 1.0f;
  gm_motion_direction = 1.0f;
  state_tick = 0U;
  gm_update_counter = 0U;
  motion_demo_telemetry.state = DEMO_START_HOLD;

  motor[Motor1].ctrl.mode = mit_mode;
  motor[Motor1].ctrl.pos_set = dm_zero_rad;
  motor[Motor1].ctrl.vel_set = 0.0f;
  motor[Motor1].ctrl.kp_set = DM_MIT_KP;
  motor[Motor1].ctrl.kd_set = DM_MIT_KD;
  motor[Motor1].ctrl.tor_set = 0.0f;
  update_gm_pwm();
}

void motion_demo_tick_1khz(void)
{
  const float dm_step = DM_TEST_RATE_DEG_S * CONTROL_PERIOD_S;
  const float gm_step_50hz = GM_TEST_RATE_DEG_S / 50.0f;

  switch (motion_demo_telemetry.state)
  {
    case DEMO_START_HOLD:
      state_tick++;
      if (state_tick >= DEMO_START_HOLD_MS)
      {
        set_state(DEMO_BOTH_RUNNING);
      }
      break;

    case DEMO_BOTH_RUNNING:
      dm_relative_deg += dm_motion_direction * dm_step;
      if (dm_relative_deg >= DM_TEST_AMPLITUDE_DEG)
      {
        dm_relative_deg = DM_TEST_AMPLITUDE_DEG;
        dm_motion_direction = -1.0f;
      }
      else if (dm_relative_deg <= -DM_TEST_AMPLITUDE_DEG)
      {
        dm_relative_deg = -DM_TEST_AMPLITUDE_DEG;
        dm_motion_direction = 1.0f;
        motion_demo_telemetry.dm_cycle_count++;
      }

      gm_update_counter++;
      if (gm_update_counter >= GM_UPDATE_DIVIDER)
      {
        gm_update_counter = 0U;
        gm_relative_deg += gm_motion_direction * gm_step_50hz;
        if (gm_relative_deg >= GM_TEST_AMPLITUDE_DEG)
        {
          gm_relative_deg = GM_TEST_AMPLITUDE_DEG;
          gm_motion_direction = -1.0f;
        }
        else if (gm_relative_deg <= -GM_TEST_AMPLITUDE_DEG)
        {
          gm_relative_deg = -GM_TEST_AMPLITUDE_DEG;
          gm_motion_direction = 1.0f;
          motion_demo_telemetry.gm_cycle_count++;
        }
        update_gm_pwm();
      }
      break;

    default:
      dm_relative_deg = 0.0f;
      gm_relative_deg = 0.0f;
      update_gm_pwm();
      set_state(DEMO_START_HOLD);
      break;
  }

  motor[Motor1].ctrl.pos_set = dm_zero_rad +
                               DM_TEST_DIRECTION * dm_relative_deg * DEG_TO_RAD;
  motion_demo_telemetry.dm_relative_angle_deg = dm_relative_deg;
  motion_demo_telemetry.gm_relative_angle_deg = gm_relative_deg;
}
