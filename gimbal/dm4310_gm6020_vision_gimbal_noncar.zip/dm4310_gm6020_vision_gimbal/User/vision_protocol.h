#ifndef __VISION_PROTOCOL_H__
#define __VISION_PROTOCOL_H__

#include "main.h"
#include <stdint.h>

#define VISION_FRAME_LENGTH             32U
#define VISION_PROTOCOL_VERSION          1U
#define VISION_MESSAGE_MEASUREMENT    0x20U

typedef enum
{
  VISION_MODE_IDLE = 0,
  VISION_MODE_TARGET = 1,
  VISION_MODE_DRONE = 2
} vision_mode_t;

typedef enum
{
  VISION_SEARCHING = 0,
  VISION_TRACKING = 1,
  VISION_TEMP_LOST = 2,
  VISION_FAULT = 3
} vision_tracking_state_t;

typedef struct
{
  uint8_t flags;
  uint16_t packet_sequence;
  uint32_t frame_id;
  uint32_t track_id;
  int32_t yaw_error_urad;
  int32_t elevation_error_urad;
  uint16_t measurement_age_ms;
  uint16_t confidence_permille;
  uint8_t tracking_state;
  uint8_t mode;
} vision_measurement_t;

typedef struct
{
  uint32_t valid_frame_count;
  uint32_t crc_error_count;
  uint32_t format_error_count;
} vision_protocol_stats_t;

extern volatile vision_protocol_stats_t vision_protocol_stats;

void vision_protocol_init(void);
uint8_t vision_protocol_feed_byte(uint8_t byte, vision_measurement_t *measurement);
uint16_t vision_crc16_ccitt_false(const uint8_t *data, uint16_t length);

#endif /* __VISION_PROTOCOL_H__ */
