# DM4310 + GM6020 PWM 同时运动测试

> 注意：当前新工程已经改为视觉云台控制，请优先阅读 `VISION_GIMBAL.md`。旧的 `motion_demo.c/.h` 不再加入Keil编译和运行入口。

本工程用于在 STM32H723VGT6 控制板上测试：

- DM4310：FDCAN1，MIT 位置控制命令频率 1 kHz。
- GM6020：PE9/TIM1_CH1，舵机式位置 PWM，输出频率 50 Hz。
- 上电保持 1 秒后，两个电机以不同速度同时连续往返。

## 接线

### DM4310

保持原工程接线：FDCAN1 使用 PD0 RX、PD1 TX，经 CAN 收发器连接电机。

### GM6020

使用控制板右侧标有 `PE09 / TIM1_CH1` 的三针接口：

```text
GM6020 白线（PWM/RX） -> PE9 信号脚
GM6020 黑线（GND）    -> GND
GM6020 灰线（TX）     -> 悬空
接口旁的 5V           -> 不接
```

GM6020 使用独立 24 V 动力电源。不得使用三针接口的 5 V 为电机供电。

GM6020 必须先在 RoboMaster Assistant 中配置成 PWM 位置控制模式。PWM 模式没有向 STM32 返回电机角度、转速、电流和温度，因此本测试由 GM6020 内部编码器完成位置闭环。

## 时序与运动流程

TIM3 每 1 ms 进入一次中断：更新 DM4310 目标并发送 MIT 控制帧，因此 DM 控制频率为 1 kHz。

TIM1 使用 1 MHz 计数和 20000 个计数周期，持续输出 50 Hz PWM：

```text
TIM1 Prescaler = 240 - 1
TIM1 Period    = 20000 - 1
1 count        = 1 us
```

GM6020 的目标脉宽只在 TIM3 每累计 20 次后更新一次，即每 20 ms 更新，目标更新频率也是 50 Hz。

运动流程如下：

1. 上电保持 1秒，DM 保持上电位置，GM 输出 1500 us。
2. 两轴同时启动。
3. DM 以 10°/s 在 -20°～+20°之间连续往返。
4. GM 以 30°/s 在 -30°～+30°之间连续往返。
5. 两轴使用各自独立的方向和循环计数，互不等待。

两个角度的 0°都是程序启动时的测试基准：DM 的 0°为初始化时反馈位置，GM 的 0°为 1500 us 对应位置。

## 参数调整

所有常用参数集中在 `User/motion_demo.h`：

```c
#define DM_TEST_RATE_DEG_S       10.0f
#define DM_TEST_AMPLITUDE_DEG    20.0f
#define DM_TEST_DIRECTION         1.0f
#define DM_MIT_KP                25.0f
#define DM_MIT_KD                 1.0f

#define GM_TEST_RATE_DEG_S       30.0f
#define GM_TEST_AMPLITUDE_DEG    30.0f
#define GM_TEST_DIRECTION         1.0f
#define GM_PWM_CENTER_US        1500.0f
#define GM_PWM_MIN_US           1080.0f
#define GM_PWM_MAX_US           1920.0f
```

若方向相反，将对应的 `DM_TEST_DIRECTION` 或 `GM_TEST_DIRECTION` 改为 `-1.0f`。

GM6020 默认按照 1080～1920 us 对应约 360°估算，因此使用 `2.3333 us/°`。实际角度映射取决于电机在 Assistant 中配置的 PWM 行程，首次运行应使用示波器确认 1500 us 和实际中心位置。

## 调试变量

Keil Watch 中可查看全局变量 `motion_demo_telemetry`：

- `state`：0表示启动保持，1表示两轴同时运动。
- `dm_relative_angle_deg`：DM 当前相对目标角度。
- `gm_relative_angle_deg`：GM 当前相对目标角度。
- `gm_pulse_us`：当前 PWM 脉宽。
- `dm_cycle_count`：DM 已完成的往返次数。
- `gm_cycle_count`：GM 已完成的往返次数。

首次运行必须架空机构或拆除负载，并准备随时切断 24 V 电源。确认正负方向、中心脉宽和机械行程后，再逐步扩大运动范围。
